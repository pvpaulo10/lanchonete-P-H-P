<?php
include('conexao.php');
include('menu.php');
Proteger();
echo 'BEM VINDO '.$_SESSION['nome'];

?>
<link rel="stylesheet" href="style.css">
