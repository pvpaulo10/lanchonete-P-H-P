<ul>
    <a href="home.php">Home</a>
    <a href="listar.php">Usuários</a>
    <a href="categorias.php">Categorias</a>
    <a href="produtos.php">Produtos</a>
    <a href="perfil.php">Perfil</a>
    <a href="sair.php">Sair</a>

</ul>